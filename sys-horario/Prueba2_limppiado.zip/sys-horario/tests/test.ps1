#g++ -std=c++17 -Iinclude tests/test_grafo.cpp -o tests/test_grafo
#tests\test_grafo.exe
g++ -std=c++17 -Iinclude src/*.cpp -o test/Main
tests\Main.exe